<?php
	echo phpinfo();
?>
