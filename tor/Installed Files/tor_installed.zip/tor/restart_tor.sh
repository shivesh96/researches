
systemctl enable tor
systemctl restart tor
systemctl status tor
sleep 1
tor
sleep 5
tor -f /etc/tor/torrc_pub
sleep 5
sudo lsof -i -P -n | grep LISTEN